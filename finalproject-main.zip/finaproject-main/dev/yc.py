#!/usr/bin/env python3

import os
import argparse
import json
from yandexcloud import SDK
from yandex.cloud.compute.v1.instance_service_pb2_grpc import InstanceServiceStub
from yandex.cloud.compute.v1.instance_service_pb2 import ListInstancesRequest
from google.protobuf.json_format import MessageToDict

def get_hosts(sdk, folder_id):

    self_hosts = []
    self_instance_service = sdk.client(InstanceServiceStub)

    hosts = self_instance_service.List(ListInstancesRequest(folder_id=folder_id))
    
    dict_ = MessageToDict(hosts)

    if dict_:
       self_hosts += dict_["instances"]

    return self_hosts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--list', action='store_true', help='Вывести весь список хостов')
    parser.add_argument('--host', help='Указать конкретный хост')
    args = parser.parse_args()

    token = os.getenv('YC_TOKEN')
    if token is None:
       print(f'Error: YC_TOKEN is not set as env variable')
       exit(1)

    sdk = SDK(iam_token=token)

    folder_id = os.getenv('yc_folder')
    if folder_id is None:
       print(f'Error: yc_folder is not set as env variable')
       exit(1)

    hosts = get_hosts(sdk, folder_id)

    file = open("inventory.yml", "w")
    file.write("[all:vars]" + "\n")
    file.write("ansible_python_interpreter='python3'" + "\n")
    file.write("[etcd_cluster]" + "\n")

    for h in hosts:
        name = h['name']
        if name.find("etcd") != -1:
          if (networkInterfaces := h.setdefault('networkInterfaces')) is not None:
            if len(networkInterfaces) >= 1:
              file.write((networkInterfaces[0].setdefault('primaryV4Address')).setdefault('address') + "\n")

    file.write("[app]" + "\n")
    for h in hosts:
        name = h['name']
        if name.find("app") != -1:
          if (networkInterfaces := h.setdefault('networkInterfaces')) is not None:
            if len(networkInterfaces) >= 1:
              file.write((networkInterfaces[0].setdefault('primaryV4Address')).setdefault('address') + "\n")

    file.write("[balancers]" + "\n")
    for h in hosts:
        name = h['name']
        if name.find("proxy") != -1:
          if (networkInterfaces := h.setdefault('networkInterfaces')) is not None:
            if len(networkInterfaces) >= 1:
              file.write((networkInterfaces[0].setdefault('primaryV4Address')).setdefault('address') + "\n")

    file.write("[postgres_cluster:children]" + "\n")
    file.write("master" + "\n")
    file.write("replica" + "\n")
    file.write("[master]" + "\n")
    for h in hosts:
        name = h['name']
        if name.find("db") != -1 and name.find("1") != -1:
          if (networkInterfaces := h.setdefault('networkInterfaces')) is not None:
            if len(networkInterfaces) >= 1:
              file.write((networkInterfaces[0].setdefault('primaryV4Address')).setdefault('address') + " hostname=" + name + ' postgresql_exists=false' + "\n")


    file.write("[replica]" + "\n")
    for h in hosts:
        name = h['name']
        if name.find("db") != -1 and name.find("1") == -1:
          if (networkInterfaces := h.setdefault('networkInterfaces')) is not None:
            if len(networkInterfaces) >= 1:
              file.write((networkInterfaces[0].setdefault('primaryV4Address')).setdefault('address') + " hostname=" + name + ' postgresql_exists=false' + "\n")

    file.close()


if __name__ == '__main__':
    main()
